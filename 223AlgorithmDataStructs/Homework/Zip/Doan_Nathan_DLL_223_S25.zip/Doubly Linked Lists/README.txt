/*
    *Name:              Nathan Doan
    *Last Modified:     5 Febrary 2025
    *Class:             223-01 Algorithm & Abstract Data
    *Professor:         Prof. Johnson
    
    *Program Description: This is an implementation of a doubly linked list where each node has pointers to nodes in their sequence.
    It includes the methods: insert, remove, search (and tranverse- sort of), and print
*/
