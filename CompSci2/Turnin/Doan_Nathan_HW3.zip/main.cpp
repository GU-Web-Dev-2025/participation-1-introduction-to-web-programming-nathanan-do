#include "bank.h"
#include <iostream>

using namespace std;

int main() {

    menu();
    return 0;
    
}
