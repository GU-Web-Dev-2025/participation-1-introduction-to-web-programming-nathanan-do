/**
 * fileL        main.cpp
 * author:      Bryan Fischer, Gonzaga University
 * date:        2024-09-15
 * description: main drive file for homework 2.
 */


/* DO NO MODIFY THIS FILE */

#include "arrayProgram.h"

using namespace std;

int main(){

    runProgram();

    return 0;
}

