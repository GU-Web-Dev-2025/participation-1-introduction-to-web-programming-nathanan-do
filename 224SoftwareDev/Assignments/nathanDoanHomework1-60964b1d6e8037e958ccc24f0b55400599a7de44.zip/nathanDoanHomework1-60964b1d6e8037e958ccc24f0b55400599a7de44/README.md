# Farkle CPSC 224 Individual Project

Individual Farkle assignment repository for CPSC 224 course

- Student:  Nathan Doan
- Semester: Spring 2025
- Current assignment: Homework 1

