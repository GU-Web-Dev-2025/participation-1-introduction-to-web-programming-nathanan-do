package edu.gonzaga.Farkle;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

// Example of a test. It's just always true, but it also runs as an example.
public class GeneralTest {
    @Test
    void alwaysTrue() {
        Assertions.assertTrue(true);
    }
}
