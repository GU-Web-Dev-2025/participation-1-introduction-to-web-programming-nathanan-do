# Assignment summary documents

Please use PDF formats

Sites sourced:

https://stackoverflow.com/questions/5364278/creating-an-array-of-objects-in-java
for assistance in determining object arrays
