/**
 * file:            UtilityCalculator.cpp
 * author:          <your name>
 * date modified:   <last date you modified code>
 * description:     <short description of what the program does>
*/

#include<iostream>

using namespace std;

int main(int argc, char *argv[]){

    char customerCode;
    int meterStart, meterEnd;

    string bannerMessage;
    bannerMessage += "+-----------------------+\n";
    bannerMessage += "|  Utility  Calculator  |\n";
    bannerMessage += "+-----------------------+\n";
    cout << bannerMessage << endl;

    // You finish ...
    
    

    return 0;
}