/**
 * file:            Artillery.cpp
 * author:          
 * date modified:   
 * description:     
*/

#include<iostream>

using namespace std;

int main()
{
    double velocity = 0.0;
    double angle = 0.0;
    int minDistance = 0, maxDistance = 0, tankPosition = 0, roundNumber = 0;
    string difficulty = "";
    string playerName = "";

    string banner;
    banner += "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    banner += "  _______          _      ____        _   _   _       \n";
    banner += " |__   __|        | |    |  _ \\      | | | | | |      \n";
    banner += "    | | __ _ _ __ | | __ | |_) | __ _| |_| |_| | ___  \n";
    banner += "    | |/ _` | '_ \\| |/ / |  _ < / _` | __| __| |/ _ \\ \n";
    banner += "    | | (_| | | | |   <  | |_) | (_| | |_| |_| |  __/ \n";
    banner += "    |_|\\__,_|_| |_|_|\\_\\ |____/ \\__,_|\\__|\\__|_|\\___| \n";
    banner += "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
                                                     
    cout << banner << endl << endl;

    

    



    

    return 0;
}
