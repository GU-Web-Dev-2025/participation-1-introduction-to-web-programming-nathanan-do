/**
 * file:            Assignment2.cpp
 * author:          <your name>
 * date modified:   <date last modified>
 * description:     <write a short description about what your program does here>
 * 
 */

#include<iostream>
using namespace std;

int main(){

    cout << "--Light Speed Distance Calculator--" << endl;

    //write your code here


    return 0;
}
