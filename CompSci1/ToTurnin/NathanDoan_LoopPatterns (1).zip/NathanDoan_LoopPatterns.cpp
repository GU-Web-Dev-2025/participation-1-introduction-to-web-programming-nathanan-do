/**
 * file:            LoopPatterns.cpp
 * author:          Nathan Doan
 * date modified:   7 March 2024
 * description:     This program outputs a pattern using loops based on the pattern's criteria
*/


#include <iostream>
using namespace std;

int main() {

  cout << "Pattern 1" << endl;
  for (int i = 0; i < 10; i++) {
      cout << "* " << endl;
  }
  cout << endl << endl;

  
  cout << "Pattern 2" << endl;
  for (int i = 0; i < 10; i++) {
      cout << "* ";
  }
  cout << endl << endl;


  cout << "Pattern 3" << endl;
  for (int i = 0; i < 10; i++) {
    for (int i = 0; i < 10; i++) {
        cout << "* ";
    }
    cout << endl;
  }
  cout << endl << endl;


  cout << "Pattern 4" << endl;
  
  for (int j = 1; j < 11; j++){
    for (int i = 0; i < j; i++) {
      cout << "* ";
    }
    cout << endl << endl;
  }

  
  cout << "Pattern 5" << endl;

  for (int j = 10; j > 0; j--){
    for (int i = 0; i < j; i++) {
      cout << "* ";
    }
    cout << endl << endl;
  }

  
  cout << "Pattern 6" << endl;

  for (int j = 2; j < 10; j+=2){
    for (int i = 0; i < j; i++) {
      cout << "* ";
    }
    cout << endl << endl;
  }


  cout << "Pattern 7" << endl;

  for (int i = 0; i < 10; i++){
  if (i == 2 || i == 4 || i == 6 || i == 8){
    for (int j = -1; j < i; j++){
    cout << "* ";
    }
    cout << endl;
  }
    else {
      cout << "* " << endl;
    }
  }
  cout << endl;
  

  cout << "Pattern 8" << endl;

  for (int i=0; i<12; i++){
    if (i == 0 || i == 4 || i == 6 || i == 8 || i == 10){
      for (int j = 0; j<10; j++){
        cout << "X ";
      }
      cout << endl;
    }
    else if (i == 0 || i == 3 || i == 5 || i == 7 || i == 9 || i == 11){
      for (int k = 0; k < 10; k++){
        cout << "O ";
      }
      cout << endl;
    }
  }
  cout << endl;


  cout << "Pattern 9" << endl;
  
  for (int j = 0; j<10; j++){
    for (int i = 0; i < 10; i++){
      if (i==0 || i==2 || i==4 || i==6 || i==8) {
        cout << "X ";
      }
      else if (i==1 || i==3 || i==5 || i==7 || i==9){
        cout << "O ";
      }
    }
    cout << endl;
  }
  cout << endl;


  cout << "Pattern 10" << endl;

  int j = 1, l = 9;
  for (int k=0; k<10; k++){

    for (int i=1; i<10; i++){
      if (i==j){
        cout << "X ";
      }
      if (i==l){
        cout << "X ";
      }
      else {
        cout << "O ";
      }
    }

    if (j==5){
      l = 5; 

      j++;
    }
    else {
      l--;
      j++;

    }
     if (j == 11){
       cout << "X ";
     }
       cout << endl; 
  }

  
    return 0;
}