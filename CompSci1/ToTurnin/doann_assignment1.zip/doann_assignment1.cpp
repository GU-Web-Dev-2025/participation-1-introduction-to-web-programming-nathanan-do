
/**
* File:          HelloWorld.cpp
* Author:        Nathan Doan
* Date:          Jan 19, 2024
* Description:   This code prints Hello World!
*/

#include <iostream>

int main(int argc, char *argv[]) {
  
  std::cout << "Hello, World!"  << std::endl;

  return 0;
}